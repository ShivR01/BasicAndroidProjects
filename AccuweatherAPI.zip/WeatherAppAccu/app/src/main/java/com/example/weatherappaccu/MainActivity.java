package com.example.weatherappaccu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ForecastUtility fc = new ForecastUtility();
        fc.execute();
        fc.ParseJson();
        ArrayList<Forecast> forecasts = fc.ParseJson();

        ListView forecastListView  = findViewById(R.id.forecastListView);

//        String[] forecastStringArray = new String[forecasts.size()];
//
//        for (int i=0; i<forecasts.size(); i++)
//        {
//            forecastStringArray[i] = forecasts.get(i).toString();
//        }
//
//        ArrayAdapter<String> itemsAdapter =
//                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, forecastStringArray);
//
//        forecastListView.setAdapter(itemsAdapter);

        ForecastAdapter forecastAdapter = new ForecastAdapter(this, 0, forecasts);
        forecastListView.setAdapter(forecastAdapter);
    }
}
