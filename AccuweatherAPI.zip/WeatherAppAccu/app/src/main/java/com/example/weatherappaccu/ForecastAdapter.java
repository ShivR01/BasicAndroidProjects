package com.example.weatherappaccu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ForecastAdapter extends ArrayAdapter<Forecast> {

    Context fContext;
    ArrayList<Forecast> forecasts;

    public ForecastAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Forecast> list) {
        super(context, 0, list);
        fContext = context;
        forecasts = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;

        if (listItem == null)
        {
            listItem = LayoutInflater.from(fContext).inflate(R.layout.list_item, parent, false);
        }

        Forecast currentForecast = forecasts.get(position);

        ImageView icon = listItem.findViewById(R.id.imageView_Icon);
        String icon0 = String.format("%02d",currentForecast.getIcon());
        String url = "https://developer.accuweather.com/sites/default/files/" +icon0 + "-s.png";
        Picasso.get()
                .load(url)
                .into(icon);

        TextView date = listItem.findViewById(R.id.textView_Date);
        date.setText(currentForecast.getDate());

        TextView condition = listItem.findViewById(R.id.textView_IconPhrase);
        condition.setText(currentForecast.getIconPhrase());

        TextView min = listItem.findViewById(R.id.textView_Min);
        min.setText(String.valueOf(currentForecast.getMinTemp()));

        TextView max = listItem.findViewById(R.id.textView_Max);
        max.setText(String.valueOf(currentForecast.getMaxTemp()));


        return listItem;
    }
}
