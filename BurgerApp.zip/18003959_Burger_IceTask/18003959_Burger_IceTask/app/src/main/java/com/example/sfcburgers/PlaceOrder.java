package com.example.sfcburgers;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class PlaceOrder extends AppCompatActivity {
    DatePickerDialog picker;
    EditText date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);

        date= findViewById(R.id.tvDate);
        date.setInputType(InputType.TYPE_NULL);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);

                picker = new DatePickerDialog(PlaceOrder.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                date.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });

    }

    public void placeOrderClicked(View view)
    {
        EditText name,date,location,burger,soda;

        name = findViewById(R.id.tvName);
        date = findViewById(R.id.tvDate);
        burger = findViewById(R.id.etBurger);
        soda = findViewById(R.id.etSodas);
        location = findViewById(R.id.etLocation);

        Intent intent = new Intent(this,Details.class);

        intent.putExtra("cusName", name.getText().toString());
        intent.putExtra("date", date.getText().toString());
        intent.putExtra("location", location.getText().toString());
        intent.putExtra("numBurger", burger.getText().toString());
        intent.putExtra("numSoda", soda.getText().toString());

        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_Welcome)
        {
            startActivity(new Intent(PlaceOrder.this, Welcome.class));
        }

        if (id == R.id.menu_Order)
        {
            Toast.makeText(getApplicationContext(),
                    "Already on Order page.", Toast.LENGTH_SHORT).show();
        }

        if (id == R.id.menu_History)
        {
            Toast.makeText(getApplicationContext(),
                    "Coming soon", Toast.LENGTH_SHORT).show();
        }

        if (id == R.id.menu_Logout)
        {
            Intent intent = new Intent(PlaceOrder.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}
