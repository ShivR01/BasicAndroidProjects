package com.example.sfcburgers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class ExtraShare extends AppCompatActivity {
    ImageButton dial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extra_share);

        dial = findViewById(R.id.btnDial);
    }

    public void onDialClick(View v) {

        if (ContextCompat.checkSelfPermission(ExtraShare.this,Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(ExtraShare.this, new String[]{Manifest.permission.CALL_PHONE},1);
        }else{
            startActivity(new Intent(Intent.ACTION_CALL,Uri.parse("tel:1234567890")));
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_Welcome)
        {
            startActivity(new Intent(ExtraShare.this, Welcome.class));
        }

        if (id == R.id.menu_Order)
        {
            startActivity(new Intent(ExtraShare.this, PlaceOrder.class));
        }

        if (id == R.id.menu_History)
        {
            Toast.makeText(getApplicationContext(),
                    "Coming soon", Toast.LENGTH_SHORT).show();
        }

        if (id == R.id.menu_Logout)
        {
            Intent intent = new Intent(ExtraShare.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
