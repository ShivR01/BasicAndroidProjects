package com.example.sfcburgers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void openWelcome()
    {
        Intent intent = new Intent(this,Welcome.class);

        startActivity(intent);
    }

    public void loginClicked(View view)
    {
        ed1 = findViewById(R.id.editText1);
        ed2 = findViewById(R.id.editText2);

        if (ed1.getText().toString().equals("User1") &&  //checks if credentials equal hard coded values
                ed2.getText().toString().equals("admin")) {
            Toast.makeText(getApplicationContext(),
                    "Redirecting...", Toast.LENGTH_SHORT).show();
            openWelcome(); //launches main screen
        }else{
            Toast.makeText(getApplicationContext(),
                    "Invalid Username/password", Toast.LENGTH_SHORT).show();
        }
    }
}
