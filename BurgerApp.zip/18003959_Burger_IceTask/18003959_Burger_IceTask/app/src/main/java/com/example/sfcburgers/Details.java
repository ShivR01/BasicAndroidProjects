package com.example.sfcburgers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Details extends AppCompatActivity {

    TextView name,date,location,burQuan,drinkQuan,tot;
    String messageDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Bundle b = getIntent().getExtras();
        double total;
        total = ((Double.parseDouble(b.getString("numBurger"))*49)+((Double.parseDouble(b.getString("numSoda"))*25)));

        name = findViewById(R.id.tvName);
        date = findViewById(R.id.tvDate);
        location = findViewById(R.id.tvLocation);
        burQuan = findViewById(R.id.tvBur);
        drinkQuan = findViewById(R.id.tvDrink);
        tot = findViewById(R.id.tvTot);

        name.setText(b.getString("cusName"));
        date.setText(b.getString("date"));
        location.setText(b.getString("location")); //need to change
        burQuan.setText(b.getString("numBurger"));
        drinkQuan.setText(b.getString("numSoda"));
        tot.setText("R"+total);


    }

    public void onProceedClick(View view)
    {
        Intent intent = new Intent(Details.this,Share.class);

        messageDetails = "Customer name: "+name.getText().toString() +"\n\nDate ordered: "+date.getText().toString()+"\n\nLocation: "+ location.getText().toString()
                +"\n\nNumber of burgers: "+burQuan.getText().toString()+"\n\nNumber of sodas: "+drinkQuan.getText().toString()+"\n\nTotal price = "+tot.getText();

        intent.putExtra("MessageDetails", messageDetails);

        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_Welcome)
        {
            startActivity(new Intent(Details.this, Welcome.class));
        }

        if (id == R.id.menu_Order)
        {
            startActivity(new Intent(Details.this, PlaceOrder.class));
        }

        if (id == R.id.menu_History)
        {
            Toast.makeText(getApplicationContext(),
                    "Coming soon", Toast.LENGTH_SHORT).show();
        }

        if (id == R.id.menu_Logout)
        {
            Intent intent = new Intent(Details.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
