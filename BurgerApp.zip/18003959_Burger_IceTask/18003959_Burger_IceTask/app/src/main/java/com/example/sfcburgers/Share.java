package com.example.sfcburgers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Share extends AppCompatActivity {
EditText to,sub,message;
    String subject,messageDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);

        Bundle b = getIntent().getExtras();

         subject = "Burger details";
         messageDetails = b.getString("MessageDetails");
        to = findViewById(R.id.toEmail);
        sub = findViewById(R.id.subject);
        message = findViewById(R.id.details);

        sub.setText(subject);
        message.setText(messageDetails);

        Button buttonShare = findViewById(R.id.btnShare);
        buttonShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMail();
            }
        });
    }

    private void sendMail()
    {
        String  recipientList = to.getText().toString();


        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL,recipientList);
        intent.putExtra(Intent.EXTRA_SUBJECT,subject);
        intent.putExtra(Intent.EXTRA_TEXT,messageDetails);

        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent,"choose an email client"));

    }

    public void onProceedClick(View v)
    {
        startActivity(new Intent(Share.this, ExtraShare.class));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_Welcome)
        {
            startActivity(new Intent(Share.this, Welcome.class));
        }

        if (id == R.id.menu_Order)
        {
            startActivity(new Intent(Share.this, PlaceOrder.class));
        }

        if (id == R.id.menu_History)
        {
            Toast.makeText(getApplicationContext(),
                    "Coming soon", Toast.LENGTH_SHORT).show();
        }

        if (id == R.id.menu_Logout)
        {
            Intent intent = new Intent(Share.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}
