package com.example.beanboozled30;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class CustomViewMove extends View{ //18003959

    Bitmap minion,bean;

    int minX =0,minY =0;
    boolean flag = false;
    final int min = 100;
    final int max = 800;

    int[] images = {R.drawable.bean1,R.drawable.bean2,R.drawable.beantogether};
    int randomNum = 0;

    public void setRandom(int randomNum){
        this.randomNum = randomNum;
    }
    //Random rand = new Random();

    //public void setMinX(int minX) {
    //    this.minX = minX;
    //}

    //public void setMinY(int minY) {
    //    this.minY = minY;
    //}

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public CustomViewMove(Context context) {
        super(context);
        setBackgroundResource(R.drawable.backcandy);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        flag = false;
        //randomNum = rand.nextInt(images.length);
        minX = getRandomPosition();
        minY = getRandomPosition();
        return super.onTouchEvent(event);

    }

    public int getRandomPosition() {
        int random = new Random().nextInt((max - min) + 1) + min;
        return random;
    }

    @Override
    protected void onDraw(Canvas canvas) {

        super.onDraw(canvas);

        bean = BitmapFactory.decodeResource(getResources(), images[randomNum]);
        minion = BitmapFactory.decodeResource(getResources(), R.drawable.bobnew);
        canvas.drawBitmap(minion,minX,minY,null);
        if (flag == true){
            canvas.drawBitmap(bean,minX-180,minY-200,null);
        }
        invalidate();
    }
}
