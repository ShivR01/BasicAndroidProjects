package com.example.shiva.workout2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class BMI extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);
    }

    public void CalcBMIButton(View view){
        EditText weightString =findViewById(R.id.editText4);
        float weightFloat = Float.valueOf(weightString.getText().toString());

        EditText heightString =findViewById(R.id.editText5);
        float heightFloat = Float.valueOf(heightString.getText().toString());

        float total = weightFloat / (heightFloat*heightFloat);
        String.format(total+".2f");
        TextView textView = findViewById(R.id.textView4);
        String totalString = Float.toString(total);
        textView.setText(totalString);
    }
}
