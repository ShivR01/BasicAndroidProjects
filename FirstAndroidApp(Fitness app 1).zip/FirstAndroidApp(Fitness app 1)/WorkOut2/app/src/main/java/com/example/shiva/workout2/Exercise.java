package com.example.shiva.workout2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Exercise extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise);

        Button b1 = (Button) findViewById(R.id.button6);
        Button b2 = (Button) findViewById(R.id.button7);
        Button b3 = (Button) findViewById(R.id.button8);
        Button b4 = (Button) findViewById(R.id.button9);
        Button b5 = (Button) findViewById(R.id.button10);

        b1.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Exercise.this,benchpop.class));
            }
        });

        b2.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Exercise.this,biceppop.class));
            }
        });

        b3.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Exercise.this,pulluppop.class));
            }
        });

        b4.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Exercise.this,squatpop.class));
            }
        });

        b5.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Exercise.this,situppop.class));
            }
        });
    }
}
