package com.example.flappybird;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class GameView extends View { //18003959

    int canvasWidth;
    int canvasHeight;

    Bitmap bird[] = new Bitmap[2];
    int birdX = 10;
    int birdY;
    int birdSpeed;

    int blueX;
    int blueY;
    int blueSpeed = 15;
    Paint bluePaint = new Paint();

    int blackX;
    int blackY;
    int blackSpeed = 20;
    Paint blackPaint = new Paint();

    Bitmap backImage;

    Bitmap life[] = new Bitmap[2];
    int life_count;

    boolean touch_flag = false;


    Paint scoreP = new Paint();
    int score;

    Paint levelP = new Paint();


    public GameView(Context context) {
        super(context);

        bird[0] = BitmapFactory.decodeResource(getResources(), R.drawable.bird1);
        bird[1] = BitmapFactory.decodeResource(getResources(), R.drawable.bird2);

        backImage = BitmapFactory.decodeResource(getResources(), R.drawable.bg);

        bluePaint.setColor(Color.BLUE);
        bluePaint.setAntiAlias(false);

        blackPaint.setColor(Color.BLACK);
        blackPaint.setAntiAlias(false);

        scoreP.setColor(Color.BLACK);
        scoreP.setTextSize(32);
        scoreP.setTypeface(Typeface.DEFAULT_BOLD);
        scoreP.setAntiAlias(true);

        levelP.setColor(Color.DKGRAY);
        levelP.setTextSize(32);
        levelP.setTypeface(Typeface.DEFAULT_BOLD);
        levelP.setTextAlign(Paint.Align.CENTER);
        levelP.setAntiAlias(true);

        life[0] = BitmapFactory.decodeResource(getResources(), R.drawable.heart);
        life[1] = BitmapFactory.decodeResource(getResources(), R.drawable.heart_g);

        birdY = 500;
        score = 0;
        life_count = 3;
    }

    @Override
    protected void onDraw(Canvas canvas) {

        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();

        canvas.drawBitmap(backImage, 0, 0, null);

        int minBirdY = bird[0].getHeight();
        int maxBirdY = canvasHeight - bird[0].getHeight() * 3;

        birdY += birdSpeed;
        if (birdY < minBirdY) birdY = minBirdY;
        if (birdY > maxBirdY) birdY = maxBirdY;
        birdSpeed += 2;

        if (touch_flag){
            canvas.drawBitmap(bird[1], birdX, birdY, null);
            touch_flag = false;
        } else{
            canvas.drawBitmap(bird[0], birdX, birdY, null);
        }

        blueX -= blueSpeed;
        if (hitCheck(blueX, blueY)){
            score += 10;
            blueX = -100;
        }
        if (blueX < 0){
            blueX = canvasWidth + 20;
            blueY = (int) Math.floor(Math.random() * (maxBirdY - minBirdY)) + minBirdY;
        }
        canvas.drawCircle(blueX, blueY, 10, bluePaint);

        blackX -= blackSpeed;
        if (hitCheck(blackX, blackY)){
            blackX = -100;
            life_count--;
            if (life_count == 0){
                Log.v("MESSAGE", "GAME OVER");
            }
        }
        if (blackX < 0){
            blackX = canvasWidth + 200;
            blackY = (int) Math.floor(Math.random() * (maxBirdY - minBirdY)) + minBirdY;
        }
        canvas.drawCircle(blackX, blackY, 20, blackPaint);


        canvas.drawText("Score : " + score, 20, 60, scoreP);

        canvas.drawText("Lv.1", canvasWidth / 2, 60, levelP);

        for (int i = 0; i < 3; i++ ){
            int x = (int) (840 + life[0].getWidth() * 1.5 * i);
            int y = 30;

            if ( i < life_count){
                canvas.drawBitmap(life[0], x, y, null);
            }else{
                canvas.drawBitmap(life[1], x, y, null);
            }
        }
    }

    public boolean hitCheck(int x, int y){
        if (birdX < x && x < (birdX + bird[0].getWidth()) && birdY < y && y < (birdY + bird[0].getWidth())){
            return true;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN){
            touch_flag = true;
            birdSpeed = -20;
        }
        return true;
    }
}
